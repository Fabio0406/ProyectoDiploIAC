aws_region = "us-east-1"

access_key = "AKIA5O2I4BG7OIP2XV6U"
secret_key = "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"

project_name = "banca-g8"
image_tag    = "latest"

db_username = "bancaadmin"
db_password = "Proy1234!"